-- lua/marvin/trixie_bridge.lua
-- Thin bridge: connects the running nvim marvin plugin to Trixie's marvin
-- IPC socket ($XDG_RUNTIME_DIR/trixie-marvin.sock).
--
-- Responsibilities:
--   • Detect and push project state whenever the project changes
--   • Stream every job output line to Trixie in real time
--   • Receive action triggers from Trixie and execute them via marvin.build
--   • Maintain a reconnect loop so Trixie restart is seamless
--
-- Usage: add to your marvin setup() call:
--
--   require('marvin.trixie_bridge').setup()
--
-- Nothing breaks if Trixie is not running — all socket errors are silent.

local M            = {}

-- ── Config ────────────────────────────────────────────────────────────────────
local RECONNECT_MS = 2000
local PING_MS      = 5000

-- ── State ─────────────────────────────────────────────────────────────────────
local state        = {
  sock      = nil, -- vim.loop TCP/pipe handle
  connected = false,
  rbuf      = '',  -- read accumulator
  ping_tmr  = nil,
  recon_tmr = nil,
  _setup    = false,
}

-- ── Helpers ───────────────────────────────────────────────────────────────────
local function sock_path()
  local xdg = os.getenv('XDG_RUNTIME_DIR') or '/tmp'
  return xdg .. '/trixie-marvin.sock'
end

local function json_escape(s)
  s = tostring(s or '')
  s = s:gsub('\\', '\\\\')
  s = s:gsub('"', '\\"')
  s = s:gsub('\n', '\\n')
  s = s:gsub('\r', '\\r')
  s = s:gsub('\t', '\\t')
  return s
end

local function send_raw(msg)
  if not state.connected or not state.sock then return end
  local ok, err = pcall(function()
    state.sock:write(msg .. '\n')
  end)
  if not ok then
    -- write error — treat as disconnect
    state.connected = false
  end
end

local function send_json(obj)
  local parts = { '{' }
  local first = true
  for k, v in pairs(obj) do
    if not first then parts[#parts + 1] = ',' end
    first = false
    parts[#parts + 1] = '"' .. json_escape(k) .. '":'
    if type(v) == 'number' then
      parts[#parts + 1] = tostring(v)
    elseif type(v) == 'boolean' then
      parts[#parts + 1] = v and 'true' or 'false'
    else
      parts[#parts + 1] = '"' .. json_escape(tostring(v)) .. '"'
    end
  end
  parts[#parts + 1] = '}'
  send_raw(table.concat(parts))
end

-- ── Project state serialisation ───────────────────────────────────────────────
local function project_kv(proj)
  if not proj then return '' end
  local info    = proj.info or {}
  local version = info.version or ''
  local lines   = {
    'name=' .. (proj.name or ''),
    'type=' .. (proj.type or ''),
    'lang=' .. (proj.lang or ''),
    'root=' .. (proj.root or ''),
    'version=' .. version,
  }
  return table.concat(lines, '\n')
end

local function push_project(proj)
  proj = proj or (pcall(require, 'marvin.detector') and require('marvin.detector').get())
  if not proj then return end
  send_json({ type = 'state', payload = project_kv(proj) })
end

-- ── Console streaming ─────────────────────────────────────────────────────────
-- Hook into core.runner so every output line is forwarded to Trixie.
local _runner_hooked = false
local function hook_runner()
  if _runner_hooked then return end
  local ok, runner = pcall(require, 'core.runner')
  if not ok then return end
  _runner_hooked = true

  -- on_start: push status=running
  local _orig_start = runner.on_start
  runner.on_start(function(entry)
    if _orig_start then pcall(_orig_start, entry) end
    send_json({
      type   = 'status',
      status = 'running',
      action = entry and (entry.action or entry.title or '') or '',
      cmd    = entry and (entry.cmd or '') or '',
    })
  end)

  -- on_finish: push status=ok/fail
  local _orig_finish = runner.on_finish
  runner.on_finish(function(entry)
    if _orig_finish then pcall(_orig_finish, entry) end
    send_json({
      type   = 'status',
      status = entry and (entry.success and 'ok' or 'fail') or 'fail',
      action = entry and (entry.action or entry.title or '') or '',
      cmd    = entry and (entry.cmd or '') or '',
    })
  end)

  -- Monkey-patch execute to intercept output lines.
  -- core.runner stores output in entry.output[] — we watch for new lines
  -- via a polling autocmd on job activity rather than patching every codepath.
  -- A 250ms timer checks running jobs and forwards new lines.
  local sent_idx = {} -- track how many lines we've forwarded per action_id
  local stream_tmr = vim.loop.new_timer()
  stream_tmr:start(0, 250, vim.schedule_wrap(function()
    if not state.connected then return end
    local running = runner.get_running and runner.get_running() or {}
    for _, job in ipairs(running) do
      local id  = job.action_id or job.cmd or '?'
      local out = job.output or {}
      local idx = sent_idx[id] or 0
      for i = idx + 1, #out do
        send_json({ type = 'console', line = tostring(out[i]) })
      end
      sent_idx[id] = #out
    end
    -- also check recently finished entries for unsent lines
    local history = runner.history and runner.history or {}
    for _, entry in ipairs(history) do
      local id  = entry.action_id or entry.cmd or '?'
      local out = entry.output or {}
      local idx = sent_idx[id] or 0
      if idx < #out then
        for i = idx + 1, #out do
          send_json({ type = 'console', line = tostring(out[i]) })
        end
        sent_idx[id] = #out
      end
    end
  end))
end

-- ── Trigger handler (Trixie → nvim) ──────────────────────────────────────────
local function handle_trigger(action)
  -- Map Trixie action ids to marvin.build functions
  local build_ok, build = pcall(require, 'marvin.build')
  if not build_ok then return end

  local handlers = {
    build     = function() build.build() end,
    run       = function() build.run() end,
    build_run = function() build.build_and_run() end,
    test      = function() build.test() end,
    clean     = function() build.clean() end,
    fmt       = function() build.fmt() end,
    lint      = function() build.lint() end,
    package   = function() build.package() end,
    install   = function() build.install() end,
    dashboard = function()
      local ok, dash = pcall(require, 'marvin.dashboard')
      if ok then vim.schedule(dash.open) end
    end,
    reload    = function()
      local ok, det = pcall(require, 'marvin.detector')
      if ok then
        det.reload(); push_project(det.get())
      end
    end,
    stop      = function() build.stop() end,
  }

  -- task trigger: "__task__<name>"
  if action:match('^__task__') then
    local det  = require('marvin.detector')
    local proj = det.get()
    if proj then
      local tasks = require('marvin.tasks')
      tasks.handle_action(action, proj)
    end
    return
  end

  local h = handlers[action]
  if h then vim.schedule(h) end
end

-- ── Message dispatch ──────────────────────────────────────────────────────────
local function handle_message(json)
  -- Minimal JSON parse for the two keys we care about
  local typ = json:match('"type"%s*:%s*"([^"]+)"')
  if not typ then return end

  if typ == 'trigger' then
    local action = json:match('"action"%s*:%s*"([^"]+)"')
    if action then handle_trigger(action) end
  elseif typ == 'pong' then
    -- heartbeat reply — do nothing
  end
end

-- ── Read accumulator ──────────────────────────────────────────────────────────
local function on_data(_, data, _)
  if not data then
    -- EOF / error
    state.connected = false
    if state.sock then pcall(state.sock.close, state.sock) end
    state.sock = nil
    return
  end
  state.rbuf = state.rbuf .. data
  while true do
    local nl = state.rbuf:find('\n', 1, true)
    if not nl then break end
    local line = state.rbuf:sub(1, nl - 1)
    state.rbuf = state.rbuf:sub(nl + 1)
    if #line > 0 then
      pcall(handle_message, line)
    end
  end
end

-- ── Connect ───────────────────────────────────────────────────────────────────
local function connect()
  if state.connected then return end
  local path = sock_path()
  if vim.fn.filereadable(path) == 0 then return end

  local sock = vim.loop.new_pipe(false)
  if not sock then return end

  sock:connect(path, function(err)
    if err then
      sock:close()
      return
    end
    state.sock      = sock
    state.connected = true
    state.rbuf      = ''

    sock:read_start(on_data)

    -- Push current project immediately on connect
    vim.schedule(function()
      local ok, det = pcall(require, 'marvin.detector')
      if ok then push_project(det.get()) end
      hook_runner()
    end)
  end)
end

-- ── Reconnect loop ────────────────────────────────────────────────────────────
local function start_reconnect_loop()
  if state.recon_tmr then return end
  state.recon_tmr = vim.loop.new_timer()
  state.recon_tmr:start(0, RECONNECT_MS, vim.schedule_wrap(function()
    if not state.connected then connect() end
  end))
end

-- ── Ping loop ─────────────────────────────────────────────────────────────────
local function start_ping_loop()
  if state.ping_tmr then return end
  state.ping_tmr = vim.loop.new_timer()
  state.ping_tmr:start(PING_MS, PING_MS, vim.schedule_wrap(function()
    if state.connected then
      send_json({ type = 'ping' })
    end
  end))
end

-- ── Autocommands ──────────────────────────────────────────────────────────────
local function setup_autocmds()
  local grp = vim.api.nvim_create_augroup('MarvinTrixieBridge', { clear = true })

  -- Push state whenever the directory changes (new project)
  vim.api.nvim_create_autocmd({ 'DirChanged', 'BufEnter' }, {
    group    = grp,
    callback = function()
      if not state.connected then return end
      vim.defer_fn(function()
        local ok, det = pcall(require, 'marvin.detector')
        if ok then push_project(det.detect()) end
      end, 100)
    end,
  })

  -- Push updated state after a build finishes
  vim.api.nvim_create_autocmd('User', {
    group    = grp,
    pattern  = 'MarvinJobFinished',
    callback = function()
      if not state.connected then return end
      local ok, det = pcall(require, 'marvin.detector')
      if ok then push_project(det.get()) end
    end,
  })
end

-- ── Public API ────────────────────────────────────────────────────────────────
function M.setup()
  if state._setup then return end
  state._setup = true

  setup_autocmds()
  start_reconnect_loop()
  start_ping_loop()
end

-- Force-push the current project state (useful for :MarvinReload etc.)
function M.push_now()
  if not state.connected then return end
  local ok, det = pcall(require, 'marvin.detector')
  if ok then push_project(det.get()) end
end

-- Expose connection status
function M.is_connected() return state.connected end

function M.socket_path() return sock_path() end

return M
